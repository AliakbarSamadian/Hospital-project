import java.io.*;
import java.util.Scanner;
import java.io.IOException;
public class Hospital {

    public static void main(String[] args) {
        System.out.print("""
                1.nurse
                2.patient addmision
                Please enter a number to select one of options above:
                """);
        Scanner scanner = new Scanner(System.in);
        int option = scanner.nextInt();
        if (option==1){
            System.out.println("\033[H\033[2J");
            System.out.flush();
            Scanner scanner1 = new Scanner(System.in);
            int remainingAttempts = 3;
            boolean isAuthenticated = false;

            while (remainingAttempts > 0) {
                System.out.print("Enter nurse code: ");
                String inputCode = scanner1.nextLine();
                System.out.print("Enter password (Attempts left: " + remainingAttempts + "): ");
                String inputPassword = scanner1.nextLine();

                if (isPasswordCorrect(inputCode, inputPassword)) {
                    isAuthenticated = true;
                    break;
                } else {
                    System.out.println("Incorrect password or nurse code. Try again.");
                    remainingAttempts--;
                }
            }

            if (isAuthenticated) {
                System.out.println("\033[H\033[2J");
                System.out.flush();
                System.out.print("""
                            1.update patient file
                            2.change password
                            Please enter a number to select one of options above:
                            """);
                int option1 = scanner.nextInt();
                if (option1==1) {
                    editDrugs();
                }

            } else {
                System.out.println("You do not have access to this application.");
                System.exit(0);
            }


            scanner1.close();

        }


    }

    private static boolean isPasswordCorrect(String inputCode, String inputPassword) {
        try {
            File file = new File("code1.txt");
            Scanner fileScanner = new Scanner(file);

            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split(" , ");
                if (parts.length == 2 && parts[0].equals(inputCode) && parts[1].equals(inputPassword)) {
                    fileScanner.close();
                    return true;
                }
            }
            fileScanner.close();
        } catch (FileNotFoundException e) {
            System.err.println("Error reading nurse credentials from file: " + e.getMessage());
            System.exit(0);
        }
        return false;
    }

    public static int countLines(String filePath) {
        try {
            Scanner scanner = new Scanner(new File(filePath));
            int lineCount = 0;

            while (scanner.hasNextLine()) {
                scanner.nextLine();
                lineCount++;
            }

            scanner.close();
            return lineCount;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return -1;
        }
    }


    public static void editDrugs() {

        String filePath = "code.txt";
        try {

            Scanner scanner1 = new Scanner(System.in);
            Scanner reader = new Scanner(new File(filePath));
            System.out.println("please enter patient key:");
            String patientkey = scanner1.next();

            if(keypatient(patientkey)){
                System.out.println("enter patient's drugs:");
                String drugs = scanner1.next();

                String[][] twoDArray = new String[countLines(filePath)][5];
                for (int i = 0;i<countLines(filePath);i++) {
                    String line = reader.nextLine();
                    String[] lineContents = line.split(" - ");
                    twoDArray[i] = lineContents;
                }

                scanner1.close();
                reader.close();
                File file2 = new File("code2.txt");
                try(BufferedWriter writer = new BufferedWriter(new FileWriter("code2.txt"))){
                    for(int i=0;i<countLines(filePath);i++){
                        if(twoDArray[i][0].equals(patientkey)){
                            twoDArray[i][4] = drugs;
                        }
                    }

                    for(int i=0;i<countLines(filePath);i++){
                        String line = String.join(" - ",twoDArray[i]);
                        writer.write(line);
                        writer.write(System.lineSeparator());
                    }
                    writer.close();
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean keypatient(String patientkey){
        try {
            File file = new File("code.txt");
            Scanner fileScanner = new Scanner(file);

            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split(" - ");
                if (parts[0].equals(patientkey)) {
                    fileScanner.close();
                    return true;
                }
            }
            fileScanner.close();
        } catch (FileNotFoundException e) {
            System.err.println("Error reading patient credentials from file: " + e.getMessage());
            System.exit(0);
        }
        return false;
    }

}